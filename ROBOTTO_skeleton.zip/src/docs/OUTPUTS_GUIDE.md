# Guia dos 4 Outputs Clínicos

1) **Relatório do caso clínico** — idade, sexo, áreas, sintomas, evolução, top‑dx e rationale breve.
2) **Sinais de alarme e vigilância** — agregados de todos os motores acionados.
3) **Cuidados gerais iniciais** — seguros e genéricos por área (linguagem leiga).
4) **Tipo de atendimento** — Amb/Rotina, Telemed, Emergência geral/especializada.
