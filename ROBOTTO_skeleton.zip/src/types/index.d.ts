// Tipagens JSDoc/TS — contratos principais. Sem implementação.
export type Area = "ouvido" | "nariz" | "garganta" | "pescoco";
