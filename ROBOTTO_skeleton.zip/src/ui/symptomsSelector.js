// [UI] seleção guiada de sintomas. Sem implementação.
