// [UI] seleção de área (multi). Sem implementação.
