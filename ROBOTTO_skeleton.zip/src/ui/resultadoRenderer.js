// [UI] render de probabilidades e 4 outputs. Sem implementação.
