// [UI] controlador chat-like e estados. Sem implementação.
