// [CORE] blend inter-áreas e LLM. Sem implementação.
