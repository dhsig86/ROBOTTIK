// [CORE] gera 4 outputs (resumo, sinais de alarme, cuidados, via). Sem implementação.
