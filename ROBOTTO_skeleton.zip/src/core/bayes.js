// [CORE] util Bayes (odds/log-odds). Sem implementação.
