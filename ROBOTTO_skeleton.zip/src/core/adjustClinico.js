// [CORE] ajustes demográficos/curso clínico. Sem implementação.
