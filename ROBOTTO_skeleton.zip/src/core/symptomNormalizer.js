// [CORE] normalização de texto livre -> labels. Sem implementação.
