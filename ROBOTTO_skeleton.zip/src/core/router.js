// [CORE] orquestração multiárea. Sem implementação.
