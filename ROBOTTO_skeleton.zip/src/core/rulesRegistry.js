// [CORE] resolve/valida bases por área. Sem implementação.
