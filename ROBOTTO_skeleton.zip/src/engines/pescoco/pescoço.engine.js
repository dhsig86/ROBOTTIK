// [ENGINE:pescoco] triage/validate/redFlags. Sem implementação.
