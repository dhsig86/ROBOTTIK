// [ENGINE:nariz] triage/validate/redFlags. Sem implementação.
