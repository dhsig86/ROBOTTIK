// [COMPAT] ponte com robotto.js 5.1.0. Sem implementação.
