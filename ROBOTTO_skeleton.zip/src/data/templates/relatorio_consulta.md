<!-- Template de relatório clínico. Sem conteúdo por enquanto. -->
