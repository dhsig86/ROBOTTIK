// [API] LLM fallback (FastAPI /api/triage). Sem implementação.
