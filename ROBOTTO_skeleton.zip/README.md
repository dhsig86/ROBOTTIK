# ROBOTTO — Skeleton (Arquitetura por Áreas)
Gerado em 2025-08-23. Estrutura inicial de pastas e arquivos **sem implementação de código**, para iniciar o projeto modular por áreas (Ouvido, Nariz, Garganta, Pescoço).

Consulte `/src/` para módulos core, engines por área, UI, API e dados (templates/lexicons).