// TODO: bootstrap do app. Sem implementação por enquanto.
