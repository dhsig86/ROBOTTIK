Coloque aqui as imagens do mascote OTTO:
- otto-1024.png
- otto-256.png
- otto-rounded.png
